﻿Start-Job  {



Write-Host "This is my 20 seconds script" ; pingggg 127.0.0.1 -t ; start-sleep 20

}