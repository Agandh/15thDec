﻿Start-Job  {

get-service 

}



Get-Job -Name Job1 | fl
Get-Job -Name Job1 | fl
$savejob = receive-Job -Name job4 -keep