﻿Start-Job  {



Write-Host "This is my 60 seconds script" { get-service } start-sleep 60

}