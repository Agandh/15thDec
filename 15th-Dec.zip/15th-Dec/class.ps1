﻿

class Name


{

[string] $firstname = "aaa"
[string] $lastname = "bbb"

[string] getfullname() {return "$(.$firstname) $(.$lastname)"}



}

$objname = New-Object -type Name


$objname.firstname = "Agandh"
$objname.firstname
$objname.lastname = "Damodare"
$objname.lastname
$objname.getfullname()



#not working need to practise