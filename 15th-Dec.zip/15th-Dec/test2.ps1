﻿$mytest1 = "new2"

write-host "this is value from second script $mytest1 "



# need to check