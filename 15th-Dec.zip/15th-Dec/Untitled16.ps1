﻿Start-Job  {



Write-Host "This is my 20 seconds script" { Get-Processss } start-sleep 20

}