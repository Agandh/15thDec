﻿#$global:test = "my session value"
#Write-Host "This is my script variable $script:test"

#$global:test= "My new value"
#Write-Host "This is my 1st script value $test"

$mytest1 = " This is my first script value"

Write-Host

& "E:\Agandh\15th-Dec\test2.ps1"



# Need to check