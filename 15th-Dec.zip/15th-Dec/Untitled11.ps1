﻿$env:PSModulePath
New-Variable -Name myvar -Value 10 -Scope global 


